To get the current version of mtsieve along with documentation for it and programs building upon it,
go to http://www.mersenneforum.org/rogue/mtsieve.html.